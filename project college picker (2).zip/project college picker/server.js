// Import necessary modules
const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configure MySQL connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Aditi@12345',
    database: 'collegepicker',
    connectionLimit: 10
});

pool.getConnection((err, connection) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
    connection.release();
});

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Added to handle JSON responses

// Define helper functions
app.locals.formatLocation = function(location) {
    // Replace underscores with spaces and capitalize each word
    return location
        .split(/[_\s]+/g)
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
};

app.locals.capitalizeFirstLetter = function(string) {
    if (!string) return '';
    return string.charAt(0).toUpperCase() + string.slice(1);
};

// Route Definitions

// Change this to serve land.html instead of home.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'land.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

app.get('/filter', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'filter.html'));
});

app.get('/filter-results', (req, res) => {
    // Extract filter parameters from query
    const {
        intermediateMarks,
        jeePercentile,
        location,
        fees,
        rank,
        course
    } = req.query;

    // Helper function to compare values
    const isAbove = (filterValue, collegeValue) => {
        const filterNumber = parseInt(filterValue, 10);
        const collegeNumber = parseInt(collegeValue, 10);
        return !isNaN(filterNumber) && !isNaN(collegeNumber) && collegeNumber >= filterNumber;
    };

    // Filter colleges based on criteria
    const filteredColleges = colleges.filter(college => {
        return (
            (!intermediateMarks || isAbove(intermediateMarks, college.intermediateMarks)) &&
            (!jeePercentile || isAbove(jeePercentile, college.jeePercentile)) &&
            (!location || college.location === location) &&
            (!fees || college.fees === fees) &&
            (!rank || college.rank === rank) &&
            (!course || college.course === course)
        );
    });

    // Render the results using the EJS template
    res.render('filter-results', { filteredColleges });
});

// Register a new user
app.post('/register', (req, res) => {
    const { name, email, password } = req.body;

    // Check if the email is already registered
    const checkEmailSql = 'SELECT * FROM users WHERE email = ?';
    pool.query(checkEmailSql, [email], (err, results) => {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).json({ error: 'Error checking email' });
        }

        if (results.length > 0) {
            // Email already exists
            return res.status(409).json({ error: 'This email is already registered' });
        }

        // Email does not exist, proceed to register the user
        bcrypt.hash(password, 10, (err, hash) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.status(500).json({ error: 'Error registering user' });
            }
            const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
            pool.query(sql, [name, email, hash], (err) => {
                if (err) {
                    console.error('Error inserting user into database:', err);
                    return res.status(500).json({ error: 'Error registering user' });
                }
                console.log('User registered successfully');
                res.status(200).json({ success: true });
            });
        });
    });
});

// Login user
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const sql = 'SELECT * FROM users WHERE email = ?';
    pool.query(sql, [email], (err, results) => {
        if (err) {
            console.error('Error querying user:', err);
            return res.status(500).json({ error: 'Error logging in' });
        }
        if (results.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        bcrypt.compare(password, results[0].password, (err, match) => {
            if (err) {
                console.error('Error comparing passwords:', err);
                return res.status(500).json({ error: 'Error logging in' });
            }
            if (!match) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }
            console.log('User logged in successfully');
            res.status(200).json({ success: true });
        });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

const colleges = [
    { name: 'Savitribai Phule Pune University', intermediateMarks: '60', jeePercentile: '50', location: 'maharashtra', fees: 'low', rank: '1', course: 'mathematics' },
    { name: 'St. Stephen\'s College', intermediateMarks: '60', jeePercentile: '60', location: 'delhi', fees: 'high', rank: '2', course: 'science' },
    { name: 'Christ University', intermediateMarks: '60', jeePercentile: '80', location: 'karnataka', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Madras Christian College', intermediateMarks: '90', jeePercentile: '50', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'mathematics' },
    { name: 'College of Engineering, Pune', intermediateMarks: '70', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Miranda House', intermediateMarks: '80', jeePercentile: '70', location: 'delhi', fees: 'low', rank: '3', course: 'science' },
    { name: 'Mount Carmel College', intermediateMarks: '60', jeePercentile: '80', location: 'karnataka', fees: 'high', rank: '1', course: 'arts' },
    { name: 'Loyola College', intermediateMarks: '90', jeePercentile: '90', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'mathematics' },
    { name: 'Veermata Jijabai Technological Institute (VJTI)', intermediateMarks: '70', jeePercentile: '60', location: 'maharashtra', fees: 'high', rank: '3', course: 'engineering' },
    { name: 'Hindu College', intermediateMarks: '60', jeePercentile: '70', location: 'delhi', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Jain University', intermediateMarks: '50', jeePercentile: '70', location: 'karnataka', fees: 'low', rank: '1', course: 'arts' },
    { name: 'Presidency College', intermediateMarks: '90', jeePercentile: '90', location: 'tamilnadu', fees: 'high', rank: '3', course: 'mathematics' },
    { name: 'Jawaharlal Nehru University', intermediateMarks: '70', jeePercentile: '80', location: 'delhi', fees: 'medium', rank: '1', course: 'social sciences' },
    { name: 'Indian Institute of Technology Bombay', intermediateMarks: '80', jeePercentile: '90', location: 'maharashtra', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'University of Calcutta', intermediateMarks: '60', jeePercentile: '70', location: 'westbengal', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Banaras Hindu University', intermediateMarks: '80', jeePercentile: '80', location: 'uttarpradesh', fees: 'medium', rank: '2', course: 'science' },
    { name: 'University of Hyderabad', intermediateMarks: '70', jeePercentile: '70', location: 'telangana', fees: 'low', rank: '3', course: 'mathematics' },
    { name: 'Panjab University', intermediateMarks: '60', jeePercentile: '70', location: 'punjab', fees: 'medium', rank: '3', course: 'engineering' },
    { name: 'Jadavpur University', intermediateMarks: '80', jeePercentile: '80', location: 'westbengal', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'National Institute of Technology Karnataka', intermediateMarks: '80', jeePercentile: '90', location: 'karnataka', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Aligarh Muslim University', intermediateMarks: '70', jeePercentile: '70', location: 'uttarpradesh', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Vellore Institute of Technology (VIT)', intermediateMarks: '100', jeePercentile: '100', location: 'tamilnadu', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Manipal Institute of Technology (MIT)', intermediateMarks: '100', jeePercentile: '100', location: 'karnataka', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'GLA University', intermediateMarks: '100', jeePercentile: '100', location: 'uttarpradesh', fees: 'medium', rank: '1', course: 'social sciences' },
    { name: 'Amity University', intermediateMarks: '100', jeePercentile: '100', location: 'uttarpradesh', fees: 'high', rank: '2', course: 'management' },
    { name: 'S.R.M. Institute of Science and Technology (SRMIST)', intermediateMarks: '100', jeePercentile: '100', location: 'tamilnadu', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Rajiv Gandhi Institute of Technology (RGIT)', intermediateMarks: '100', jeePercentile: '100', location: 'mumbai', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'LPU (Lovely Professional University)', intermediateMarks: '100', jeePercentile: '100', location: 'punjab', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'K. L. University', intermediateMarks: '100', jeePercentile: '100', location: 'andhrapradesh', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Chandigarh University', intermediateMarks: '100', jeePercentile: '100', location: 'chandigarh', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Delhi University', intermediateMarks: '50', jeePercentile: '50', location: 'maharashtra', fees: 'low', rank: '1', course: 'mathematics' },
    { name: 'Annamalai University', intermediateMarks: '75', jeePercentile: '65', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Bharathiar University', intermediateMarks: '65', jeePercentile: '55', location: 'tamilnadu', fees: 'low', rank: '3', course: 'science' },
    { name: 'Birla Institute of Technology', intermediateMarks: '80', jeePercentile: '90', location: 'ranchi', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Dr. Babasaheb Ambedkar Marathwada University', intermediateMarks: '70', jeePercentile: '65', location: 'maharashtra', fees: 'medium', rank: '2', course: 'social sciences' },
    { name: 'Guru Nanak Dev University', intermediateMarks: '80', jeePercentile: '75', location: 'punjab', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Himachal Pradesh University', intermediateMarks: '65', jeePercentile: '60', location: 'himachal pradesh', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Indian Institute of Technology Delhi', intermediateMarks: '90', jeePercentile: '95', location: 'delhi', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Kanpur', intermediateMarks: '85', jeePercentile: '90', location: 'uttarpradesh', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Jamia Millia Islamia', intermediateMarks: '80', jeePercentile: '75', location: 'delhi', fees: 'medium', rank: '2', course: 'social sciences' },
    { name: 'Jawaharlal Nehru Technological University', intermediateMarks: '70', jeePercentile: '60', location: 'telangana', fees: 'medium', rank: '3', course: 'engineering' },
    { name: 'Kalinga Institute of Industrial Technology', intermediateMarks: '80', jeePercentile: '85', location: 'odisha', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Karnataka State Open University', intermediateMarks: '70', jeePercentile: '65', location: 'karnataka', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Mahatma Gandhi University', intermediateMarks: '75', jeePercentile: '70', location: 'kerala', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Manonmaniam Sundaranar University', intermediateMarks: '65', jeePercentile: '60', location: 'tamilnadu', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Maulana Azad National Institute of Technology', intermediateMarks: '80', jeePercentile: '90', location: 'bhopal', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Mysore University', intermediateMarks: '70', jeePercentile: '60', location: 'karnataka', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Narendra Dev University of Agriculture and Technology', intermediateMarks: '60', jeePercentile: '55', location: 'uttarpradesh', fees: 'low', rank: '3', course: 'agriculture' },
    { name: 'Netaji Subhas Open University', intermediateMarks: '70', jeePercentile: '65', location: 'westbengal', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Osmania University', intermediateMarks: '80', jeePercentile: '85', location: 'telangana', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Panjab University', intermediateMarks: '70', jeePercentile: '60', location: 'punjab', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Patna University', intermediateMarks: '60', jeePercentile: '55', location: 'bihar', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Periyar University', intermediateMarks: '75', jeePercentile: '70', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Punjab Agricultural University', intermediateMarks: '70', jeePercentile: '65', location: 'punjab', fees: 'high', rank: '1', course: 'agriculture' },
    { name: 'Ravenshaw University', intermediateMarks: '80', jeePercentile: '90', location: 'odisha', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Sardar Vallabhbhai National Institute of Technology', intermediateMarks: '85', jeePercentile: '80', location: 'gujarat', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Shivaji University', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'low', rank: '3', course: 'science' },
    { name: 'Sikkim Manipal University', intermediateMarks: '65', jeePercentile: '60', location: 'sikkim', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Symbiosis International University', intermediateMarks: '90', jeePercentile: '95', location: 'maharashtra', fees: 'high', rank: '1', course: 'management' },
    { name: 'Tezpur University', intermediateMarks: '80', jeePercentile: '75', location: 'assam', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Thapar University', intermediateMarks: '85', jeePercentile: '90', location: 'punjab', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'University of Agricultural Sciences', intermediateMarks: '70', jeePercentile: '65', location: 'karnataka', fees: 'low', rank: '3', course: 'agriculture' },
    { name: 'University of Delhi', intermediateMarks: '75', jeePercentile: '70', location: 'delhi', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'University of Jammu', intermediateMarks: '80', jeePercentile: '85', location: 'jammu', fees: 'medium', rank: '2', course: 'science' },
    { name: 'University of Kerala', intermediateMarks: '85', jeePercentile: '80', location: 'kerala', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'University of Lucknow', intermediateMarks: '70', jeePercentile: '65', location: 'uttarpradesh', fees: 'low', rank: '3', course: 'arts' },
    { name: 'University of Madras', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'high', rank: '1', course: 'science' },
    { name: 'University of Pune', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'University of Rajasthan', intermediateMarks: '60', jeePercentile: '50', location: 'rajasthan', fees: 'low', rank: '3', course: 'science' },
    { name: 'University of South Asia', intermediateMarks: '80', jeePercentile: '90', location: 'bangladesh', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Utkal University', intermediateMarks: '70', jeePercentile: '65', location: 'odisha', fees: 'high', rank: '2', course: 'engineering' },
    { name: 'Vidyasagar University', intermediateMarks: '75', jeePercentile: '70', location: 'westbengal', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Visvesvaraya National Institute of Technology', intermediateMarks: '85', jeePercentile: '90', location: 'nagpur', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Yashwantrao Chavan Maharashtra Open University', intermediateMarks: '60', jeePercentile: '50', location: 'maharashtra', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Indian Institute of Technology Madras', intermediateMarks: '85', jeePercentile: '90', location: 'tamilnadu', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Hyderabad', intermediateMarks: '80', jeePercentile: '85', location: 'telangana', fees: 'high', rank: '2', course: 'engineering' },
    { name: 'Indian Institute of Technology Guwahati', intermediateMarks: '90', jeePercentile: '92', location: 'assam', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Jawaharlal Nehru University', intermediateMarks: '75', jeePercentile: '70', location: 'delhi', fees: 'medium', rank: '3', course: 'social sciences' },
    { name: 'Pune University', intermediateMarks: '78', jeePercentile: '80', location: 'maharashtra', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Manipal University', intermediateMarks: '85', jeePercentile: '88', location: 'karnataka', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Sri Ramakrishna Engineering College', intermediateMarks: '70', jeePercentile: '60', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Bangalore University', intermediateMarks: '60', jeePercentile: '70', location: 'karnataka', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Jadavpur University', intermediateMarks: '85', jeePercentile: '90', location: 'westbengal', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Banaras Hindu University', intermediateMarks: '80', jeePercentile: '85', location: 'uttarpradesh', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Vellore Institute of Technology (VIT)', intermediateMarks: '90', jeePercentile: '95', location: 'tamilnadu', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Management Ahmedabad', intermediateMarks: '80', jeePercentile: '85', location: 'gujarat', fees: 'high', rank: '2', course: 'management' },
    { name: 'Indian Institute of Management Bangalore', intermediateMarks: '90', jeePercentile: '90', location: 'karnataka', fees: 'high', rank: '1', course: 'management' },
    { name: 'Shiv Nadar University', intermediateMarks: '85', jeePercentile: '90', location: 'uttarpradesh', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Symbiosis International University', intermediateMarks: '80', jeePercentile: '75', location: 'maharashtra', fees: 'high', rank: '1', course: 'management' },
    { name: 'University of Calcutta', intermediateMarks: '60', jeePercentile: '70', location: 'westbengal', fees: 'low', rank: '2', course: 'arts' },
    { name: 'University of Delhi', intermediateMarks: '65', jeePercentile: '70', location: 'delhi', fees: 'medium', rank: '1', course: 'science' },
    { name: 'University of Hyderabad', intermediateMarks: '70', jeePercentile: '75', location: 'telangana', fees: 'low', rank: '2', course: 'mathematics' },
    { name: 'University of Pune', intermediateMarks: '80', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Anna University', intermediateMarks: '75', jeePercentile: '85', location: 'tamilnadu', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Amity University', intermediateMarks: '80', jeePercentile: '85', location: 'uttarpradesh', fees: 'high', rank: '2', course: 'management' },
    { name: 'Mysore University', intermediateMarks: '70', jeePercentile: '60', location: 'karnataka', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Guru Nanak Dev University', intermediateMarks: '80', jeePercentile: '75', location: 'punjab', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Shivaji University', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'low', rank: '3', course: 'science' },
    { name: 'Netaji Subhas University', intermediateMarks: '80', jeePercentile: '70', location: 'westbengal', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Mahatma Gandhi University', intermediateMarks: '75', jeePercentile: '70', location: 'kerala', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Visvesvaraya National Institute of Technology', intermediateMarks: '85', jeePercentile: '90', location: 'nagpur', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Manipal Institute of Technology', intermediateMarks: '80', jeePercentile: '85', location: 'karnataka', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Osmania University', intermediateMarks: '80', jeePercentile: '85', location: 'telangana', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'University of Jammu', intermediateMarks: '85', jeePercentile: '80', location: 'jammu', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Thapar University', intermediateMarks: '85', jeePercentile: '90', location: 'punjab', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Kalinga Institute of Industrial Technology', intermediateMarks: '80', jeePercentile: '85', location: 'odisha', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Ravenshaw University', intermediateMarks: '80', jeePercentile: '90', location: 'odisha', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Patna University', intermediateMarks: '60', jeePercentile: '55', location: 'bihar', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Periyar University', intermediateMarks: '75', jeePercentile: '70', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Punjab Agricultural University', intermediateMarks: '70', jeePercentile: '65', location: 'punjab', fees: 'high', rank: '1', course: 'agriculture' },
    { name: 'Dr. Babasaheb Ambedkar Marathwada University', intermediateMarks: '70', jeePercentile: '65', location: 'maharashtra', fees: 'medium', rank: '2', course: 'social sciences' },
    { name: 'Sardar Vallabhbhai National Institute of Technology', intermediateMarks: '85', jeePercentile: '80', location: 'gujarat', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Symbiosis University', intermediateMarks: '90', jeePercentile: '95', location: 'maharashtra', fees: 'high', rank: '1', course: 'management' },
    { name: 'Shiv Nadar University (SNU)', intermediateMarks: '90', jeePercentile: '80', location: 'uttarpradesh', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'University of Agricultural Sciences', intermediateMarks: '70', jeePercentile: '65', location: 'karnataka', fees: 'low', rank: '3', course: 'agriculture' },
    { name: 'Visvesvaraya National Institute of Technology', intermediateMarks: '85', jeePercentile: '90', location: 'nagpur', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Mahatma Gandhi Engineering College', intermediateMarks: '75', jeePercentile: '80', location: 'rajasthan', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Aryabhata Science College', intermediateMarks: '70', jeePercentile: '75', location: 'delhi', fees: 'high', rank: '2', course: 'science' },
    { name: 'Bharati Vidyapeeth University', intermediateMarks: '85', jeePercentile: '90', location: 'maharashtra', fees: 'medium', rank: '1', course: 'management' },
    { name: 'Nehru College of Arts and Science', intermediateMarks: '65', jeePercentile: '60', location: 'tamilnadu', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Gandhi Institute of Technology', intermediateMarks: '80', jeePercentile: '85', location: 'karnataka', fees: 'high', rank: '2', course: 'engineering' },
    { name: 'Shivaji Maharaj College', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '1', course: 'science' },
    { name: 'Rani Durgavati University', intermediateMarks: '70', jeePercentile: '65', location: 'madhyapradesh', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Laxmi Narayan Institute of Technology', intermediateMarks: '90', jeePercentile: '95', location: 'uttarpradesh', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Pandit Deendayal University', intermediateMarks: '80', jeePercentile: '85', location: 'gujarat', fees: 'medium', rank: '1', course: 'social sciences' },
    { name: 'Bishop Heber College', intermediateMarks: '65', jeePercentile: '60', location: 'tamilnadu', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Mahatma Phule College', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Shri Ram College of Commerce', intermediateMarks: '85', jeePercentile: '90', location: 'delhi', fees: 'high', rank: '1', course: 'commerce' },
    { name: 'Vivekananda Institute of Technology', intermediateMarks: '70', jeePercentile: '65', location: 'karnataka', fees: 'low', rank: '2', course: 'engineering' },
    { name: 'Jagadguru Jayadeva Murugharajendra University', intermediateMarks: '80', jeePercentile: '85', location: 'karnataka', fees: 'medium', rank: '1', course: 'social sciences' },
    { name: 'Tata Institute of Social Sciences', intermediateMarks: '90', jeePercentile: '95', location: 'mumbai', fees: 'high', rank: '1', course: 'social sciences' },
    { name: 'Indian School of Business', intermediateMarks: '85', jeePercentile: '90', location: 'hyderabad', fees: 'high', rank: '1', course: 'management' },
    { name: 'Sardar Patel University', intermediateMarks: '75', jeePercentile: '70', location: 'gujarat', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Kumaraguru College of Technology', intermediateMarks: '70', jeePercentile: '65', location: 'tamilnadu', fees: 'low', rank: '3', course: 'engineering' },
    { name: 'Dibrugarh University', intermediateMarks: '80', jeePercentile: '85', location: 'assam', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Mysore Institute of Management', intermediateMarks: '90', jeePercentile: '90', location: 'karnataka', fees: 'high', rank: '1', course: 'management' },
    { name: 'K.L. E. Society\'s College of Engineering', intermediateMarks: '75', jeePercentile: '80', location: 'maharashtra', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Govind Ballabh Pant University', intermediateMarks: '80', jeePercentile: '85', location: 'uttaranchal', fees: 'high', rank: '1', course: 'agriculture' },
    { name: 'Srinivas College of Engineering', intermediateMarks: '70', jeePercentile: '75', location: 'karnataka', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Vivekanand College of Arts', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'low', rank: '2', course: 'arts' },
    { name: 'Indira Gandhi National Open University', intermediateMarks: '60', jeePercentile: '65', location: 'delhi', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Gujarat Technological University', intermediateMarks: '85', jeePercentile: '90', location: 'gujarat', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Sardar Vallabhbhai Patel Institute', intermediateMarks: '70', jeePercentile: '75', location: 'gujarat', fees: 'medium', rank: '2', course: 'management' },
    { name: 'Birla Institute of Technology and Science', intermediateMarks: '90', jeePercentile: '95', location: 'goa', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Shivaji College', intermediateMarks: '65', jeePercentile: '60', location: 'delhi', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Ambedkar University', intermediateMarks: '80', jeePercentile: '85', location: 'delhi', fees: 'medium', rank: '2', course: 'social sciences' },
    { name: 'Guru Nanak Institute of Technology', intermediateMarks: '75', jeePercentile: '70', location: 'punjab', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Annamalai Institute of Management', intermediateMarks: '70', jeePercentile: '65', location: 'tamilnadu', fees: 'low', rank: '2', course: 'management' },
    { name: 'Nirma University', intermediateMarks: '85', jeePercentile: '90', location: 'gujarat', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Nehru Institute of Technology', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Delhi College of Arts', intermediateMarks: '60', jeePercentile: '55', location: 'delhi', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Nehru College of Engineering and Research', intermediateMarks: '70', jeePercentile: '70', location: 'tamilnadu', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Government College of Art', intermediateMarks: '75', jeePercentile: '75', location: 'punjab', fees: 'high', rank: '1', course: 'arts' },
    { name: 'Vikram University', intermediateMarks: '80', jeePercentile: '85', location: 'madhyapradesh', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Bharatiya Vidya Bhavan', intermediateMarks: '85', jeePercentile: '90', location: 'maharashtra', fees: 'high', rank: '1', course: 'management' },
    { name: 'Asian Institute of Management', intermediateMarks: '80', jeePercentile: '85', location: 'bangalore', fees: 'high', rank: '1', course: 'management' },
    { name: 'Panjab Engineering College', intermediateMarks: '75', jeePercentile: '80', location: 'punjab', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Chandigarh College of Architecture', intermediateMarks: '70', jeePercentile: '65', location: 'chandigarh', fees: 'low', rank: '3', course: 'architecture' },
    { name: 'Indian Institute of Management', intermediateMarks: '85', jeePercentile: '90', location: 'ahmedabad', fees: 'high', rank: '1', course: 'management' },
    { name: 'Jawaharlal Nehru Technological University', intermediateMarks: '80', jeePercentile: '85', location: 'andhra pradesh', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology', intermediateMarks: '90', jeePercentile: '95', location: 'delhi', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Madhav Institute of Technology', intermediateMarks: '70', jeePercentile: '75', location: 'madhyapradesh', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Bhavan\'s College', intermediateMarks: '60', jeePercentile: '55', location: 'maharashtra', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Loyola College', intermediateMarks: '85', jeePercentile: '90', location: 'tamilnadu', fees: 'high', rank: '1', course: 'arts' },
    { name: 'Sardar Vallabhbhai Patel Institute of Technology', intermediateMarks: '75', jeePercentile: '80', location: 'gujarat', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Pondicherry University', intermediateMarks: '70', jeePercentile: '65', location: 'pondicherry', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Manipal Institute of Technology', intermediateMarks: '85', jeePercentile: '90', location: 'karnataka', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'KCG College of Technology', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'medium', rank: '1', course: 'engineering' },
    { name: 'Mahatma Jyotiba Phule University', intermediateMarks: '70', jeePercentile: '75', location: 'uttarpradesh', fees: 'low', rank: '2', course: 'science' },
    { name: 'University of Madras', intermediateMarks: '75', jeePercentile: '80', location: 'tamilnadu', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Sri Ramachandra Institute of Higher Education', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'high', rank: '1', course: 'medical' },
    { name: 'University of Pune', intermediateMarks: '90', jeePercentile: '90', location: 'maharashtra', fees: 'medium', rank: '1', course: 'science' },
    { name: 'SV University', intermediateMarks: '70', jeePercentile: '65', location: 'andhra pradesh', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Vidyasagar University', intermediateMarks: '75', jeePercentile: '80', location: 'westbengal', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Rajasthan Technical University', intermediateMarks: '80', jeePercentile: '85', location: 'rajasthan', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Shivaji University', intermediateMarks: '70', jeePercentile: '75', location: 'maharashtra', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Vivekananda Global University', intermediateMarks: '85', jeePercentile: '90', location: 'rajasthan', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Central University of Tamil Nadu', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Sri Venkateswara University', intermediateMarks: '70', jeePercentile: '65', location: 'andhra pradesh', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Panjab University', intermediateMarks: '90', jeePercentile: '90', location: 'punjab', fees: 'high', rank: '1', course: 'science' },
    { name: 'Amity University', intermediateMarks: '80', jeePercentile: '85', location: 'uttarpradesh', fees: 'medium', rank: '2', course: 'management' },
    { name: 'Jadavpur University', intermediateMarks: '75', jeePercentile: '70', location: 'westbengal', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Jawaharlal Nehru University', intermediateMarks: '85', jeePercentile: '90', location: 'delhi', fees: 'medium', rank: '1', course: 'social sciences' },
    { name: 'University of Calcutta', intermediateMarks: '70', jeePercentile: '65', location: 'westbengal', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Northeast Frontier Technical University', intermediateMarks: '60', jeePercentile: '55', location: 'arunachal pradesh', fees: 'low', rank: '3', course: 'engineering' },
    { name: 'Symbiosis Institute of Business Management', intermediateMarks: '90', jeePercentile: '95', location: 'maharashtra', fees: 'high', rank: '1', course: 'management' },
    { name: 'Kerala University', intermediateMarks: '75', jeePercentile: '80', location: 'kerala', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'Punjab Technical University', intermediateMarks: '70', jeePercentile: '65', location: 'punjab', fees: 'low', rank: '3', course: 'engineering' },
    { name: 'University of Hyderabad', intermediateMarks: '80', jeePercentile: '85', location: 'telangana', fees: 'high', rank: '1', course: 'science' },
    { name: 'University of Mumbai', intermediateMarks: '75', jeePercentile: '70', location: 'maharashtra', fees: 'medium', rank: '2', course: 'arts' },
    { name: 'Bhupendra Narayan Mandal University', intermediateMarks: '65', jeePercentile: '60', location: 'bihar', fees: 'low', rank: '3', course: 'science' },
    { name: 'Indira Gandhi Institute of Aeronautics', intermediateMarks: '85', jeePercentile: '90', location: 'delhi', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Rajasthan State Open University', intermediateMarks: '80', jeePercentile: '85', location: 'rajasthan', fees: 'medium', rank: '1', course: 'arts' },
    { name: 'University of Kashmir', intermediateMarks: '70', jeePercentile: '65', location: 'jammu and kashmir', fees: 'low', rank: '3', course: 'arts' },
    { name: 'Gujarat University', intermediateMarks: '75', jeePercentile: '70', location: 'gujarat', fees: 'medium', rank: '2', course: 'science' },
    { name: 'Manonmaniam Sundaranar University', intermediateMarks: '80', jeePercentile: '85', location: 'tamilnadu', fees: 'high', rank: '1', course: 'science' },
    { name: 'Sardar Vallabhbhai Patel University of Agriculture', intermediateMarks: '90', jeePercentile: '90', location: 'gujarat', fees: 'medium', rank: '1', course: 'agriculture' },
    { name: 'Indian Institute of Science', intermediateMarks: '90', jeePercentile: '95', location: 'karnataka', fees: 'high', rank: '1', course: 'science' },
    { name: 'Indian Institute of Technology Bombay', intermediateMarks: '85', jeePercentile: '90', location: 'maharashtra', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Management Bangalore', intermediateMarks: '80', jeePercentile: '85', location: 'karnataka', fees: 'high', rank: '1', course: 'management' },
    { name: 'Indian Institute of Management Ahmedabad', intermediateMarks: '85', jeePercentile: '90', location: 'gujarat', fees: 'high', rank: '1', course: 'management' },
    { name: 'Indian Institute of Technology Delhi', intermediateMarks: '90', jeePercentile: '95', location: 'delhi', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian School of Mines', intermediateMarks: '75', jeePercentile: '80', location: 'jharkhand', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Indian Institute of Technology Madras', intermediateMarks: '90', jeePercentile: '95', location: 'tamilnadu', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Kanpur', intermediateMarks: '85', jeePercentile: '90', location: 'uttarpradesh', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Kharagpur', intermediateMarks: '80', jeePercentile: '85', location: 'westbengal', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Roorkee', intermediateMarks: '85', jeePercentile: '90', location: 'uttarakhand', fees: 'high', rank: '1', course: 'engineering' },
    { name: 'Indian Institute of Technology Bhubaneswar', intermediateMarks: '80', jeePercentile: '85', location: 'odisha', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Indian Institute of Management Calcutta', intermediateMarks: '85', jeePercentile: '90', location: 'westbengal', fees: 'high', rank: '1', course: 'management' },
    { name: 'Indian Institute of Management Kozhikode', intermediateMarks: '80', jeePercentile: '85', location: 'kerala', fees: 'high', rank: '1', course: 'management' },
    { name: 'Indian Institute of Management Indore', intermediateMarks: '80', jeePercentile: '85', location: 'madhyapradesh', fees: 'medium', rank: '1', course: 'management' },
    { name: 'Indian Institute of Technology Mandi', intermediateMarks: '75', jeePercentile: '80', location: 'himachal pradesh', fees: 'medium', rank: '2', course: 'engineering' },
    { name: 'Indian Institute of Management Ranchi', intermediateMarks: '80', jeePercentile: '85', location: 'jharkhand', fees: 'medium', rank: '1', course: 'management' },
    ];
    