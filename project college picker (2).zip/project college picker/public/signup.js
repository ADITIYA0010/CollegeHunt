document.getElementById('signupForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch('/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(data).toString()
        });

        const result = await response.json(); // Await for JSON parsing
        if (response.ok) {
            // Redirect to login page or show a success message
            window.location.href = '/login';
        } else {
            // Show error message if registration fails
            document.getElementById('errorMessage').innerText = result.error || 'Registration failed. Please try again.';
        }
    } catch (error) {
        console.error('Error during registration:', error);
        document.getElementById('errorMessage').innerText = 'An error occurred. Please try again.';
    }
});
