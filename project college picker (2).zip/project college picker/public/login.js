document.getElementById('loginForm').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent the default form submission

    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                email: email,
                password: password
            })
        });

        const contentType = response.headers.get('Content-Type');//check wheather data is in jason form or plain txt
        let result;
        if (contentType && contentType.includes('application/json')) {
            result = await response.json();//convert jason data into js object
        } else {
            result = await response.text();//convert plain txt in string
        }

        if (response.ok && result.success) {
            window.location.href = '/filter';
        } else {
            const errorMessage = typeof result === 'string' ? result : result.error;
            document.getElementById('errorMessage').textContent = errorMessage || 'An error occurred';
        }
    } catch (error) {
        document.getElementById('errorMessage').textContent = 'An error occurred. Please try again.';
    }
});